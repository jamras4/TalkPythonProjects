# Credits

This course and related materials were made possible by a Kickstarter campaign in March 2016. Some backers gave an extra amount to ensure the course came to life and I want to thank them here.

Sincerely, Michael Kennedy

| Name | Link |  
|------|------|
|Real Python|[realpython.com](https://realpython.com)|   
|Matt Makai|[fullstackpython.com](http://fullstackpython.com)|   
|Mahmoud Hashemi|[Mahmoud on Talk Python To Me](https://talkpython.fm/episodes/show/4/enterprise-python-and-large-scale-projects)| 
|Dan Hooper|[Dan on LinkedIn](https://www.linkedin.com/in/hooperdan)| 
|Erik Martinson|[@eman_no1](http://twitter/eman_no1)|   
|Peter W.|from Austria|   
|Patrick Neise|      | 
|Paul Cook|      |   
|Pete Cook|      |   
|Tom Yarrish|      | 
|Jason Stanford|      |   
|Jack Brunier|      | 
|Xin  Zong|      |   
|Daniel Grubbs|      |   
|Brent Kincer|      | 
|Brooks Marshall|      |   
|Þórir Elvar Ólafsson|      |   
|Miles Dennis|      | 
|Doamino|      |   
|Kuncheng Li|      |   
|Mufeed Al-Hashim|      | 
|fabrifromfindon|      |   
|Mark S. Day| |
|Antti Härkönen| |
|Croizer| |
|Dallin Hunter| |
|Bill Arbuckle| |
|Jeff Kiefer| |
