print("1. About to import program")
import program
print("2. Program imported")

print("3. Printing header!")
program.print_header()
print("4. Done with program.")

